function love.conf(t)
    t.window.resizable = true;
    t.window.width = 1280;
    t.window.height = 720;
    t.console = true;
    -- t.window.width = 1920;
    -- t.window.height = 1080;
    -- t.window.fullscreen = true;
end